# Pocketplay

Offline video + music player (installable PWA). No server logic, no accounts, nothing leaves your phone.

## Install on your phone (pick one)

**A. Host once, then it works offline forever**
1. Upload this folder to any free static host (Netlify Drop, GitHub Pages, Cloudflare Pages).
2. Open the link in Chrome (Android) or Safari (iPhone) once while online.
3. Menu -> Install app / Add to Home Screen.

**B. Fully local with Termux (Android)**
1. Install Termux, then: `pkg install python`
2. Copy this folder to the phone, `cd` into it, run: `python -m http.server 8080`
3. Open `http://localhost:8080` in Chrome -> Menu -> Install app.
   (localhost counts as secure, so install works with no internet.)

## Adding your media
Tap **+** (or Library -> Add files / Add a folder) and select your videos and music.
Files are copied into the app's private storage so they play offline even if originals are deleted.
Browsers cannot scan a phone's storage on their own, so you choose files once; after that they are always there.

## Features
- Netflix-style home: hero, Continue watching, Recently added, Music rows
- Video: double-tap sides to skip 10s, speed control, fullscreen, resume where you left off, autoplay next
- Music: mini player + now-playing sheet, shuffle, repeat, lock-screen controls, background playback
- Search, remove items, storage usage

## Multiple audio tracks (Japanese / English etc.)
- Videos with several audio tracks get an **Audio** button in the player; tap it to pick a track.
- Library -> **Default audio language** makes every multi-audio video start in that language.
- It works by reordering the tracks inside the MP4/MKV file (no re-encoding, no copying, instant, fine for multi-GB files).
- A track marked with a warning sign (AC3, DTS, etc.) may be silent in some phone browsers, because the browser itself can't decode it.
